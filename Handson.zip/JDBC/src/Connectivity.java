
import java.sql.Connection;
import java.sql.DriverManager;


public class Connectivity 
{
	static Connection connection;
	
	public static Connection establishConn()  
	{
		try 
		{
			connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/HotelManagementServer", "root", "123456");
		}
		catch (Exception e) 
		{
			System.out.println("Error in connecting to DB : "+e);
		}
		return connection;
	}
	
	public static void closeConn() 
	{
		try 
		{
			connection.close();
		} 
		catch (Exception e) 
		{
			System.out.println("Error in connectiong to DB : "+e);
		}
	}
}